package com.banking.service;

import com.banking.dao.AccountDao;

public class TransferService {
	private AccountDao dao = new AccountDao();
	
	public int getBalance(int accountID) {
		return dao.getBalanceDetails(accountID);
	}
	
	public  void transferAmount(int senderAccountNumber,int receiverAccountNumber,int amount) {
		 dao.transferAmount(senderAccountNumber, receiverAccountNumber, amount);
	}

}
