package com.banking.service;

import com.banking.dao.UserDao;
import com.banking.entity.User;
import com.banking.model.UserModel;

public class UserService {

	private UserDao userDao =new UserDao();
	
	public void addUser(UserModel model) {
		User user = new User();
		user.setUserName(model.getUserName());
		user.setPassword(model.getPassword());
		user.setRole(model.getRole());
		//user.setEmail(null);
		userDao.insertUser(user);
	}
	
	public User getUser(String userName, String password) {
		return userDao.getAdmin(userName, password);
	}
}
