package com.banking.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userID;
	
	private String userName;
	
	private String password;

	private String role;
	
	private String email;
	
	@OneToOne(mappedBy = "user")
    private Account account;
	
	 @OneToOne(mappedBy = "user1")
	    private Transfer transfer1;

	    @OneToOne(mappedBy = "user2")
	    private Transfer transfer2;
	
	public User() {
		// TODO Auto-generated constructor stub
	}

	public User(int userID, String userName, String password,  String role, String email,
			Account account, Transfer transfer1, Transfer transfer2) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.password = password;
		this.role = role;
		this.email = email;
		this.account = account;
		this.transfer1 = transfer1;
		this.transfer2 = transfer2;
	}



	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Transfer getTransfer1() {
		return transfer1;
	}

	public void setTransfer1(Transfer transfer1) {
		this.transfer1 = transfer1;
	}

	public Transfer getTransfer2() {
		return transfer2;
	}

	public void setTransfer2(Transfer transfer2) {
		this.transfer2 = transfer2;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
}
