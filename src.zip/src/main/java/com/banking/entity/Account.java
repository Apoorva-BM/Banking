package com.banking.entity;

import java.util.Random;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Account {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int accountID;
	
	private int amount;
	
	private String type;
	
	private int chequeBook;
	
	@OneToOne
    private User user;

	public Account(int accountID, int amount, String type, int chequeBook, User user) {
		super();
		this.accountID = accountID;
		this.amount = amount;
		this.type = type;
		this.chequeBook = chequeBook;
		this.user = user;
	}


	public int getAccountID() {
		return accountID;
	}

	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getChequeBook() {
		return chequeBook;
	}

	public void setChequeBook(int chequeBook) {
		this.chequeBook = chequeBook;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	private String generateAccountNumber() {
        Random random = new Random();
        int randomNumber = random.nextInt(1000000);
        return String.format("AC-%06d", randomNumber);
    }
	
	
}
