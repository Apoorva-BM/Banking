package com.banking.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Transfer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transferID;
	
	@OneToOne
    private User user1;
	
	@OneToOne
    private User user2;
	
	private int amount;
	
	public Transfer() {
		// TODO Auto-generated constructor stub
	}

	public Transfer(int transferID, User user1, User user2, int amount) {
		super();
		this.transferID = transferID;
		this.user1 = user1;
		this.user2 = user2;
		this.amount = amount;
	}

	public int getTransferID() {
		return transferID;
	}

	public void setTransferID(int transferID) {
		this.transferID = transferID;
	}

	public User getUser1() {
		return user1;
	}

	public void setUser1(User user1) {
		this.user1 = user1;
	}

	public User getUser2() {
		return user2;
	}

	public void setUser2(User user2) {
		this.user2 = user2;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	
}
