package com.banking.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.banking.entity.User;
import com.banking.model.UserModel;
import com.banking.service.UserService;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService service = new UserService();
      
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String role=request.getParameter("role");
		String manager = request.getParameter("manager");
		String users = request.getParameter("user");
		UserModel model = new UserModel();
		if(manager!=null) {
			model.setRole(manager);
		}else if(users!=null) {
			model.setRole(users);
		}
		model.setPassword(password);
		model.setUserName(username);
		User user= service.getUser(username, password);
		if(user!=null) {
			if(manager!=null) {
				HttpSession session=request.getSession();
				session.setAttribute("user", user);
				RequestDispatcher rd=request.getRequestDispatcher("manager.jsp");
				rd.forward(request, response);
			}else if(users!=null) {
				HttpSession session=request.getSession();
				session.setAttribute("user", user);
				RequestDispatcher rd=request.getRequestDispatcher("user.jsp");
				rd.forward(request, response);
			}else
			{
				RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
				request.setAttribute("msg", "Username/Password is invalid");
				rd.forward(request, response);
			}
		}else
		{
			RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
			request.setAttribute("msg", "Username/Password is invalid");
			rd.forward(request, response);
		}
	}

}
