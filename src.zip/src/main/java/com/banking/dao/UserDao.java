package com.banking.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.banking.config.HibConfig;
import com.banking.entity.User;

public class UserDao {
	public void insertUser(User user) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.save(user);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		session.close();
		
	}
	
	public User getAdmin(String userName,String password) {
		SessionFactory factory=null;
		Session session=null;
		Query<User> query=null;
		User user =null;
		try
		{
		factory=HibConfig.getSessionFactory();
		session=factory.openSession();
		query=session.createQuery("select u from com.banking.entity.User u where u.userName=?1 and u.password=?2", User.class);
		query.setParameter(1, userName);
		query.setParameter(2, password);
		user=query.uniqueResult();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			session.close();
		}
		return user;
	}
	
	 public void deleteUser(String username) {
		 SessionFactory factory=null;
		 Session session=null;
		 Transaction tx = null;
		 User user =null;
		 try {
			 factory=HibConfig.getSessionFactory();
				session=factory.openSession();
	            tx = session.beginTransaction();

	            Query<User> query = session.createQuery("FROM com.banking.entity.User WHERE username = :userName", User.class);
	            query.setParameter("username", username);
	            user = query.uniqueResult();

	            if (user != null) {

	                session.delete(user);
	                System.out.println("User with username " + username + " deleted successfully");
	            } else {
	                System.out.println("User not found with username: " + username);
	            }

	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	                tx.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	
	            session.close();
	        }
	    }
}
