package com.banking.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.banking.config.HibConfig;
import com.banking.entity.Account;

public class AccountDao {
	  public int getBalanceDetails(int accountID) {
		  SessionFactory sessionFactory=null;
		  int balance = 0;
	        try {
	        	sessionFactory=HibConfig.getSessionFactory();
	            Session session = sessionFactory.getCurrentSession();
	            Account account = session.get(Account.class, accountID);
	            if (account != null) {
	                balance = account.getAmount();
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return balance;
	    }

	    public void transferAmount(int fromAccountId, int toAccountId, int amount) {
	    	SessionFactory sessionFactory=null;
	    	try {
	    		sessionFactory=HibConfig.getSessionFactory();
	             Session session = sessionFactory.getCurrentSession();
	             Account fromAccount = session.get(Account.class, fromAccountId);
	             Account toAccount = session.get(Account.class, toAccountId);

	             if (fromAccount != null && toAccount != null) {
	                 int fromAccountBalance = fromAccount.getAmount();
	                 int toAccountBalance = toAccount.getAmount();

	                 if (fromAccountBalance >= amount) {
	                     fromAccount.setAmount(fromAccountBalance-amount);
	                     toAccount.setAmount(toAccountBalance+amount);

	                     session.update(fromAccount);
	                     session.update(toAccount);
	                 } else {
	                     System.out.println("Insufficient balance in the source account.");
	                 }
	             } else {
	                 System.out.println("One or both accounts not found.");
	             }
	         } catch (Exception e) {
	             e.printStackTrace();
	         }
	     }
}
