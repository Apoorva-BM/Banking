package com.banking.model;

public class TrabsferModel {

	 private String senderName;
	    private int senderAccountNumber;
	    private String receiverName;
	    private int receiverAccountNumber;
	    private int amount;
	    
	    public TrabsferModel() {
			// TODO Auto-generated constructor stub
		}

		public TrabsferModel(String senderName, int senderAccountNumber, String receiverName,
				int receiverAccountNumber, int amount) {
			super();
			this.senderName = senderName;
			this.senderAccountNumber = senderAccountNumber;
			this.receiverName = receiverName;
			this.receiverAccountNumber = receiverAccountNumber;
			this.amount = amount;
		}

		public String getSenderName() {
			return senderName;
		}

		public void setSenderName(String senderName) {
			this.senderName = senderName;
		}

		public int getSenderAccountNumber() {
			return senderAccountNumber;
		}

		public void setSenderAccountNumber(int senderAccountNumber) {
			this.senderAccountNumber = senderAccountNumber;
		}

		public String getReceiverName() {
			return receiverName;
		}

		public void setReceiverName(String receiverName) {
			this.receiverName = receiverName;
		}

		public int getReceiverAccountNumber() {
			return receiverAccountNumber;
		}

		public void setReceiverAccountNumber(int receiverAccountNumber) {
			this.receiverAccountNumber = receiverAccountNumber;
		}

		public int getAmount() {
			return amount;
		}

		public void setAmount(int amount) {
			this.amount = amount;
		}
	    
	    
}
